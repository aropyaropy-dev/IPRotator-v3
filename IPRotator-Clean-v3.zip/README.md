# IP Rotator — clean Android starter

Upload the contents of this ZIP to the root of a GitHub repository, preserving folder paths. Commit to `main`, then open Actions and run **Android APK Build**. Download `IPRotator-debug-apk` from a successful run.

Important: this project only builds a basic starter screen. It does not yet connect to VPN servers or rotate public IP addresses. That requires multiple working VPN/proxy endpoints and a VPN backend. Do not commit private VPN keys or credentials.
