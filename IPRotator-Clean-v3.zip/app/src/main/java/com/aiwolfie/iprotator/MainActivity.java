package com.aiwolfie.iprotator;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(1);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 28, 28, 28);
        TextView text = new TextView(this);
        text.setGravity(Gravity.CENTER);
        text.setTextSize(19);
        text.setText("IP ROTATOR\n\nFresh Android starter build.\n\nVPN connection and automatic public-IP rotation are not implemented yet. Public-IP rotation requires multiple working VPN/proxy endpoints.");
        layout.addView(text);
        setContentView(layout);
    }
}
