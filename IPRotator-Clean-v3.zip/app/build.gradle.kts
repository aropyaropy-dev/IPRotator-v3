plugins { id("com.android.application") }
android {
    namespace = "com.aiwolfie.iprotator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aiwolfie.iprotator"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
